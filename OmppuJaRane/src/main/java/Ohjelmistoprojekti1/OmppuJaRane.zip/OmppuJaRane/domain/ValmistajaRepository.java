package Ohjelmistoprojekti1.OmppuJaRane.domain;

public interface ValmistajaRepository {

}
