package Ohjelmistoprojekti1.OmppuJaRane;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmppuJaRaneApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmppuJaRaneApplication.class, args);
	}

}
